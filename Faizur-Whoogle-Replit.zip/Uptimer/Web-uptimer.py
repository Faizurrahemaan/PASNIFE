import requests
import time

# URL of the website to ping
url = "https://search.faizurrahemaan.repl.co"

# Define a function to ping the website
def ping_website(url):
    try:
        response = requests.get(url)
        if response.status_code == 200:
            print(f"Website {url} is online!")
        else:
            print(f"Website {url} is down! Status code: {response.status_code}")
    except requests.ConnectionError:
        print(f"Failed to connect to {url}")

# Run the script in an infinite loop
if __name__ == "__main__":
    while True:
        ping_website(url)
        time.sleep(60)  # Sleep for 60 seconds (1 minute)
