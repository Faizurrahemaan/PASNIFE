import requests
import time
from datetime import datetime

url = "https://pasnife.faizur7.repl.co"

def ping_website(url):
    try:
        response = requests.get(url)
        if response.status_code == 200:
            status = f"[{datetime.now()}] Website is accessible."
        else:
            status = f"[{datetime.now()}] Website returned status code {response.status_code}"
    except requests.exceptions.RequestException:
        status = f"[{datetime.now()}] Website is down or unreachable."

    with open("ping_data.txt", "a") as file:
        file.write(status + "\n")
    
    print(status)

if __name__ == "__main__":
    while True:
        ping_website(url)
        time.sleep(60)